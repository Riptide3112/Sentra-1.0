<?php
// auth_check.php - Verifică Autentificarea și Autorizarea (Sistem Simplificat)

// 1. Asigură-te că sesiunea este pornită
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Verifică dacă utilizatorul are un rol permis.
 *
 * @param array $allowed_roles Rolurile permise (ex: ['staff', 'admin'])
 * @param string $redirect_on_fail Pagina unde se face redirecționarea în caz de eșec (client dashboard)
 */
function check_access($allowed_roles, $redirect_on_fail = 'dashboard.php')
{

    // 1. VERIFICARE AUTENTIFICARE: Ești logat?
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        // Redirecționează la pagina de login dacă nu e logat
        header("Location: login.php");
        exit;
    }

    // Preluăm și curățăm rolul din sesiune pentru a evita erorile de spații/majuscule
    $user_role = trim(strtolower($_SESSION['user_role'] ?? 'client'));

    // 2. VERIFICARE AUTORIZARE: Ai rolul potrivit?
    if (!in_array($user_role, $allowed_roles)) {
        // Redirecționează la pagina de client dacă rolul nu e permis
        header("Location: $redirect_on_fail");
        exit;
    }

    // Dacă am ajuns aici, accesul este permis.
    return true;
}
?>